package TestCases;

import org.testng.annotations.Test;

import PageObjectModel.HomePage;
import PageObjectModel.LoginPage;
import PageObjectModel.MyProfilePage;
import PageObjectModel.RegisterPage;
import TestBase.BaseClass;

public class TC002_LoginPageTest extends BaseClass
{
	@Test
	public void VerifyLogin() 
	{
		logger.info("**** Started TC002_LoginPageTest ****");
		
		HomePage hp = new HomePage(driver);
		hp.clickRegister();
		logger.info("**** Clicked on Register/Login ****");
		
		RegisterPage rp =new RegisterPage(driver);
		rp.ClickOnLogin();
		logger.info("**** Clicked on Login ****");
		
		
		logger.info("**** Proveding Custmer Details ****");
		LoginPage lp = new LoginPage(driver);
		
		lp.setUserName(p.getProperty("UserName"));
		lp.setPassword(p.getProperty("Password"));
		lp.clickOnRemember();
		lp.clickOnLogin();
		
		
		hp.clickOnMyProfile();
		logger.info("**** Verified MyProfile ****");
		
		MyProfilePage myac = new MyProfilePage(driver); 
		myac.validateProfile();
		
		logger.info("**** Clicked Logout ****");
		myac.clickOnLogout();
		
		logger.info("**** Finished TC002_LoginPageTest ****");
		
	}

}
