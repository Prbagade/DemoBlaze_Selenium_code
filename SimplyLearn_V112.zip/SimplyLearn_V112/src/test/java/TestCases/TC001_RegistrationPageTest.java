package TestCases;

import org.testng.annotations.Test;
import PageObjectModel.HomePage;
import PageObjectModel.MyProfilePage;
import PageObjectModel.RegisterPage;
import TestBase.BaseClass;

public class TC001_RegistrationPageTest extends BaseClass 
{

	@Test
	public void VerifyRegistration() 
	{
		logger.info("**** Starting TC001_RegistrationPageTest ****");
		HomePage hp = new HomePage(driver);
		
		hp.clickRegister();
		logger.info("**** Clicked on Acc Register ****");
		
		RegisterPage rp = new RegisterPage(driver);
		
		logger.info("**** Entering user details ****");
		rp.setUsername(p.getProperty("UserName"));
		rp.setEmail(randomAlphaNum()+"@gmail.com");
		rp.setFirstname(randomString());
		rp.setLastname(randomString());
		rp.setPassword(randomString()+"@"+randomString());
		rp.clickOnPolicy();
		rp.ClickOnRegister();
		
		MyProfilePage myac = new MyProfilePage(driver);
		
		logger.info("**** Validated profile name ****");
		myac.validateProfile();
		
		logger.info("**** Clicked Logout **** ");
		myac.clickOnLogout();
		
		logger.info("**** Finished TC001_RegistrationPageTest ****");
		
	}
}
