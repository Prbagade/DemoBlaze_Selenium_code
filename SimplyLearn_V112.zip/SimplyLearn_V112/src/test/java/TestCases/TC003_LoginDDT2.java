package TestCases;

import org.testng.annotations.Test;

import PageObjectModel.HomePage;
import PageObjectModel.LoginPage;
import PageObjectModel.MyProfilePage;
import PageObjectModel.RegisterPage;
import TestBase.BaseClass;
import UtilityClass.DataProviders;

public class TC003_LoginDDT2 extends BaseClass
{
	//@Test(dataProvider="LoginData",dataProviderClass=DataProviders.class)
	@Test
	public void VerifyLogin() 
	{
		logger.info("**** Started TC002_LoginPageTest ****");
		
		HomePage hp = new HomePage(driver);
		hp.clickRegister();
		logger.info("**** Clicked on Register/Login ****");
		
		RegisterPage rp =new RegisterPage(driver);
		rp.ClickOnLogin();
		logger.info("**** Clicked on Login ****");
		
	}
}
