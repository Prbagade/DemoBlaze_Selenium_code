package TestCases;

import org.testng.annotations.Test;

import PageObjectModel.HomePage;
import PageObjectModel.LoginPage;
import PageObjectModel.MyProfilePage;
import PageObjectModel.RegisterPage;
import TestBase.BaseClass;
import UtilityClass.DataProviders;

public class TC003_LoginDDT extends BaseClass
{
	
	@Test(dataProvider="LoginData",dataProviderClass=DataProviders.class)
	public void VerifyLoginDDT(String emailR, String pwdR,String expR) 
	{
		
		HomePage hp = new HomePage(driver);
		hp.clickRegister();
		
		RegisterPage rp =new RegisterPage(driver);
		rp.ClickOnLogin();
		
	/*	LoginPage lp = new LoginPage(driver);
		lp.setUserName(expR);
		lp.setPassword(pwdR);
		lp.clickOnLogin();
		
		hp.clickOnMyProfile();
		
		MyProfilePage myac = new MyProfilePage(driver); 
		myac.validateProfile();
		myac.clickOnLogout();
		
		System.out.println("Expected Result : "+expR+"\t"+"Email : "+emailR+"\t"+"Password : "+pwdR);
		*/
		
	}
}
