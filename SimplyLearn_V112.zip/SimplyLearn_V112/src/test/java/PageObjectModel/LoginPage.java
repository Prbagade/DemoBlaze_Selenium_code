package PageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends BasePage
{
	//setup
	public LoginPage(WebDriver driver) 
	{
		super(driver);
	}
	
	//loc
	@FindBy(xpath = "(//input[@id='user_login'])[2]") WebElement txt_UserName;
	@FindBy(xpath = "(//input[@id='user_pass'])[2]") WebElement txt_Password;
	@FindBy(xpath = "(//input[@name='rememberme'])[2]") WebElement chk_Rememberme;
	@FindBy(xpath = "(//input[@value=\"Log In\"])[2]") WebElement btn_Login;
	
	//Method
	public void setUserName(String username) 
	{
		txt_UserName.sendKeys(username);
	}
	
	public void setPassword(String pass) 
	{
		txt_Password.sendKeys(pass);
	}
	
	public void clickOnRemember() 
	{
		chk_Rememberme.click();
	}
	
	public void clickOnLogin() 
	{
		btn_Login.click();
	}
	
}
