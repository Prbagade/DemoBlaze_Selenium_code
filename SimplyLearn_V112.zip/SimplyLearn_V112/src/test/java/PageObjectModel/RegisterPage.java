package PageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegisterPage extends BasePage
{
	public RegisterPage(WebDriver driver) 
	{
		super(driver);
	}
	
	@FindBy(xpath = "//input[@id='username']") WebElement txt_UserName;
	@FindBy(xpath = "//input[@id='email']") WebElement txt_Email;
	@FindBy(xpath = "//input[@id='first_name']") WebElement txt_Fname;
	@FindBy(xpath = "//input[@id='last_name']") WebElement txt_Lname;
	@FindBy(xpath = "//input[@id='password']") WebElement txt_Password;
	@FindBy(xpath = "//input[@id='ld-privacy-checkbox']") WebElement chk_Policy;
	@FindBy(xpath = "//input[@id='wp-submit-register']") WebElement btn_Register;
	@FindBy(xpath = "//a[@class='ld-registration__login-link']") WebElement btn_Login;
	
	public void setUsername(String userName)
	{
		txt_UserName.sendKeys(userName);
	}
	
	public void setEmail(String email)
	{
		txt_Email.sendKeys(email);
	}
	
	public void setFirstname(String fname)
	{
		txt_Fname.sendKeys(fname);
	}
	
	public void setLastname(String lname)
	{
		txt_Lname.sendKeys(lname);
	}
	
	public void setPassword(String password)
	{
		txt_Password.sendKeys(password);
	}
	
	public void clickOnPolicy()
	{
		chk_Policy.click();
	}
	
	public void ClickOnRegister() 
	{
		btn_Register.click();
	}
	
	public void ClickOnLogin() 
	{
		btn_Login.click();
	}
}
