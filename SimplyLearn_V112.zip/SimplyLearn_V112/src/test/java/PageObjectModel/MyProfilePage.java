package PageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;



public class MyProfilePage extends BasePage
{
	
	public MyProfilePage(WebDriver driver) 
	{
		super(driver);
	}
	
	@FindBy(xpath = "//h2[@class='ld-profile-heading']") WebElement profileName;
	@FindBy(xpath = "//a[text()='Log out']") WebElement btn_Logout;
	
	
//	public boolean validateProfile() 
//	{
//		
//		return(profileName.isDisplayed()); 
//	}
	public void validateProfile() 
	{
		System.out.println("Profile Name = "+profileName.getText());
		 
	}
	
	public void clickOnLogout() 
	{
		btn_Logout.click();
	}
	
	

}
