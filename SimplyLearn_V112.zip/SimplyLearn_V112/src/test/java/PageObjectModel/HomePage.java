package PageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage
{
	
	public HomePage(WebDriver driver) 
	{
		super(driver);
	}
	
	@FindBy(xpath = "//span[text()='Login / Register']") WebElement btn_Register;
	@FindBy(xpath = "//span[text()='My profile']") WebElement btn_MyProfile;
	
	
	public void clickRegister() 
	{
		btn_Register.click();
	}
	
	public void clickOnMyProfile()
	{
		btn_MyProfile.click();
	}
	

}
